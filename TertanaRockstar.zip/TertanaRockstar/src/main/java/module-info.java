module com.example.teretanarockstar.tertanarockstar {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires java.sql;
    requires com.jfoenix;
    requires org.apache.commons.codec;

    opens com.example.teretanarockstar.tertanarockstar.Entieti to javafx.base;
    opens com.example.teretanarockstar.tertanarockstar to javafx.fxml;
    exports com.example.teretanarockstar.tertanarockstar;
    exports com.example.teretanarockstar.tertanarockstar.Kontroleri;
    opens com.example.teretanarockstar.tertanarockstar.Kontroleri to javafx.fxml;
}