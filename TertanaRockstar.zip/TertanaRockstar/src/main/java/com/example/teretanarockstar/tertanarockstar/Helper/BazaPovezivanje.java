package com.example.teretanarockstar.tertanarockstar.Helper;

import java.sql.Connection;
import java.sql.DriverManager;

public class BazaPovezivanje {
    public static BazaPovezivanje povObj;

    private BazaPovezivanje(){
    }

    public static synchronized BazaPovezivanje dohvatiInstancu(){
        if(povObj==null){
            povObj = new BazaPovezivanje();
        }
        return povObj;
    }

    public Connection dohvatiVezu()  {
        Connection povezanost = null;
        try {
            povezanost = DriverManager.getConnection("jdbc:mysql://82.132.0.106:3306/ucenik_kimpric", "kimpric", "kimpric123");
        }
        catch (Exception e){
            System.out.println("Povezivanje Neuspješno!");
            e.printStackTrace();
        }
        return povezanost;
    }
}
