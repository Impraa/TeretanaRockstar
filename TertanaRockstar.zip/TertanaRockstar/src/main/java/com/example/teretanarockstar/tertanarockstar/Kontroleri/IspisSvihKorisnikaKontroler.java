package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Korisnik;
import com.example.teretanarockstar.tertanarockstar.Entieti.ZahtjevDjelatnikKorisnik;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class IspisSvihKorisnikaKontroler implements Initializable {
    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public TableView<ZahtjevDjelatnikKorisnik> tablica;

    @FXML
    public TableColumn<ZahtjevDjelatnikKorisnik,String> ime;

    @FXML
    public TableColumn<ZahtjevDjelatnikKorisnik,String> prezime;

    @FXML
    public TableColumn<ZahtjevDjelatnikKorisnik,Integer> kontakt;

    @FXML
    public TableColumn<ZahtjevDjelatnikKorisnik,String> email;

    @FXML
    public TableColumn<ZahtjevDjelatnikKorisnik,String> korIme;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadiceDjelatnici.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);

        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });
        Korisnik.dohvatiInstancu();
        Korisnik.dohvatiInstancu().ispisSvihKorisnika(tablica,ime,prezime,kontakt,email,korIme);
    }
}
