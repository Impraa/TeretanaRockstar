package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Kvar;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class UnosKvaraKontroler implements Initializable {

    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public JFXTextField korIme;

    @FXML
    public JFXTextField imeSprave;

    @FXML
    public JFXTextField prozSprave;

    @FXML
    public JFXTextField cijenaPopravka;

    @FXML
    public JFXDatePicker datumNabaveSprave;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadiceDjelatnici.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);

        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });
        cijenaPopravka.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cijenaPopravka.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        korIme.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z\\d")) {
                korIme.setText(newValue.replaceAll("[^\\sa-zA-Z^\\d]", ""));
            }
        });
    }

    public void povratakKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("KvaroviPocetna.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void unosKlik(){
        Kvar.dohvatiInstancu();
        Kvar.dohvatiInstancu().UnosKvarova(korIme,imeSprave,prozSprave,datumNabaveSprave,cijenaPopravka);
    }
}
