package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

public class PrijavaKontroler {

    public void odjava(Stage prozor){
        Alert upozorenje = new Alert(Alert.AlertType.CONFIRMATION);
        upozorenje.setTitle("Upozorenje");
        upozorenje.setHeaderText("Jeste li sigurni da želite izaći iz aplikacije?");
        upozorenje.setContentText("Sve promjene koje nisu spremljene biti će zaboravljene.");

        if(upozorenje.showAndWait().get() == ButtonType.OK){
            prozor.close();
        }

    }
}
