package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Kvar;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;

public class PromjenaKvaraProzorKontroler implements Initializable {
    @FXML
    public JFXTextField korIme;

    @FXML
    public JFXTextField imeSprave;

    @FXML
    public JFXDatePicker datumNabave;

    @FXML
    public JFXTextField proizSprave;

    @FXML
    public JFXTextField cijenaPop;

    public static String korime,imesprave,prozSprave;
    public static Date datumnabave;
    public static  int cijenapop;
    public static int kvarID;

    public void postaviVrijendosti(String korIme,String imeSprave,Date datumNabave,String proizSprave,int cijenaPop,int kvarid){
        korime = korIme;
        imesprave = imeSprave;
        datumnabave = datumNabave;
        prozSprave = proizSprave;
        cijenapop = cijenaPop;
        kvarID = kvarid;
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        korIme.setText(korime);
        imeSprave.setText(imesprave);
        datumNabave.setValue(datumnabave.toLocalDate());
        proizSprave.setText(prozSprave);
        cijenaPop.setText(String.valueOf(cijenapop));

        cijenaPop.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cijenaPop.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

    }

    public void izmjenaKlik(){
        Kvar.dohvatiInstancu();
        Kvar.dohvatiInstancu().izmjenaKvarova(korIme.getText(),imeSprave.getText(),Date.valueOf(datumNabave.getValue()),proizSprave.getText(),kvarID,Integer.parseInt(cijenaPop.getText()));
    }
}
