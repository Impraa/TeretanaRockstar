package com.example.teretanarockstar.tertanarockstar.Entieti;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

import java.util.Date;

public class ZahtjevKorisnikaClanarine {

    public ZahtjevKorisnikaClanarine(Date vrijemePolaska, int osobniTrener, String presudaZahtjeva, String vrstaPlacanja) {
        this.vrijemePolaska = new SimpleObjectProperty(vrijemePolaska);
        this.osobniTrener = new SimpleIntegerProperty(osobniTrener);
        this.presudaZahtjeva = new SimpleStringProperty(presudaZahtjeva);
        this.vrstaPlacanja = new SimpleStringProperty(vrstaPlacanja);
    }

    private SimpleObjectProperty vrijemePolaska;
    private SimpleIntegerProperty osobniTrener;
    private SimpleStringProperty presudaZahtjeva, vrstaPlacanja;

    public Date getVrijemePolaska(){
        return (Date) this.vrijemePolaska.get();
    }

    public void setVrijemePolaska(String vrijemePolaska){
        this.vrijemePolaska.set(vrijemePolaska);
    }

    public Integer getOsobniTrener(){
        return this.osobniTrener.get();
    }
    public void setOsobniTrener(Integer osobniTrener){
        this.osobniTrener.set(osobniTrener);
    }

    public String getPresudaZahtjeva(){
        return  this.presudaZahtjeva.get();
    }
    public void setPresudaZahtjeva(String presudaZahtjeva){
        this.presudaZahtjeva.set(presudaZahtjeva);
    }

    public String getVrstaPlacanja(){
        return this.vrstaPlacanja.get();
    }
    public void setVrstaPlacanja(String vrstaPlacnja){
        this.vrstaPlacanja.set(vrstaPlacnja);
    }
}
