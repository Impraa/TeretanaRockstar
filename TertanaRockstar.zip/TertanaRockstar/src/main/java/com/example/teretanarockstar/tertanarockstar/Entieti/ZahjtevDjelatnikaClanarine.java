package com.example.teretanarockstar.tertanarockstar.Entieti;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

import java.time.LocalDate;
import java.util.Date;

public class ZahjtevDjelatnikaClanarine {

    public ZahjtevDjelatnikaClanarine(String korisnickoIme, Date vrijemePolaska, Date istekClanarine, Integer cijenaClanarine) {
        this.korisnickoIme = new SimpleStringProperty(korisnickoIme);
        this.vrijemePolaska = new SimpleObjectProperty(vrijemePolaska);
        this.istekClanarine = new SimpleObjectProperty(istekClanarine);
        this.cijenaClanarine = new SimpleIntegerProperty(cijenaClanarine);
    }

    private SimpleStringProperty korisnickoIme;
    private SimpleObjectProperty vrijemePolaska;
    private SimpleObjectProperty istekClanarine;
    private SimpleIntegerProperty cijenaClanarine;

    public String getKorisnickoIme(){return this.korisnickoIme.get();}

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme.set(korisnickoIme);
    }

    public Date getVrijemePolaska(){ return (Date) this.vrijemePolaska.get();}

    public void setVrijemePolaska(Object vrijemePolaska) {
        this.vrijemePolaska.set(vrijemePolaska);
    }

    public Date getIstekClanarine(){return (Date) this.istekClanarine.get();}

    public void setIstekClanarine(Object istekClanarine) {
        this.istekClanarine.set(istekClanarine);
    }

    public Integer getCijenaClanarine(){return (Integer) this.cijenaClanarine.get();}

    public void setCijenaClanarine(int cijenaClanarine) {
        this.cijenaClanarine.set(cijenaClanarine);
    }
}
