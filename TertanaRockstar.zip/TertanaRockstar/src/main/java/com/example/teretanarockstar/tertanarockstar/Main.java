package com.example.teretanarockstar.tertanarockstar;

import com.example.teretanarockstar.tertanarockstar.Kontroleri.PrijavaKontroler;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    @Override
    public void start(Stage osnovniStage) throws IOException {
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("Main.fxml"));
            Scene scene = new Scene(root);
            scene.getStylesheets().add("file:src/main/resources/com/example/teretanarockstar/tertanarockstar/application.css");


           Image img = new Image(String.valueOf(Main.class.getResource("Logo3.0.png")));
           osnovniStage.getIcons().add(img);

            osnovniStage.setScene(scene);
            osnovniStage.show();
            osnovniStage.setOnCloseRequest(e -> {
                e.consume();
                PrijavaKontroler kon = new PrijavaKontroler();
                kon.odjava(osnovniStage);
            });
            osnovniStage.setResizable(false);

        } catch (Exception e2) {
            // TODO: handle exception
            System.out.print("main");
            e2.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}