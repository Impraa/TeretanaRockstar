package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class KreatinKalkualtorKontroler implements Initializable {

    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public JFXTextField tezinaTxt;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadice.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);
        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });
    }
    public void tezinaTxtVerify(){
        tezinaTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                tezinaTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    public void kalkulacijaKreatina(){
        double tezina = Double.parseDouble(tezinaTxt.getText()) * 0.3;
        Alert Obavijest = new Alert(Alert.AlertType.INFORMATION);
        Obavijest.setHeaderText("Dnevno moraš unjeti "+ tezina + " grama kreatina, tokom faze punjenja.");
        Obavijest.setTitle("Obavijest");
        Obavijest.show();
    }
}
