package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class StvariLadiceKontroler {

    public void bmiKalkulatorKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("BMIKalkulator.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void proteinKalkulatorKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("ProteinKalkulator.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void kreatinKalkulatorKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("KreatinKalkulator.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void clanarinaZahtjevKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("ClanarinaZahtjev.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void osobniPodaciKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("OsobniPodaci.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void odjaviSeKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("Main.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }
}
