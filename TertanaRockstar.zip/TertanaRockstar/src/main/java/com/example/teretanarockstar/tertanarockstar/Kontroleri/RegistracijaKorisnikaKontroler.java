package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Korisnik;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Date;
import java.util.Objects;

public class RegistracijaKorisnikaKontroler {
    @FXML
    public JFXTextField imeTxt;

    @FXML
    public JFXTextField prezimeTxt;

    @FXML
    public JFXTextField oibTxt;

    @FXML
    public JFXTextField kontaktTxt;

    @FXML
    public JFXTextField emailTxt;

    @FXML
    public DatePicker datumRodenja;

    @FXML
    public JFXTextField korisnickoImeTxt;

    @FXML
    public JFXPasswordField lozinkaTxt;

    @FXML
    public JFXPasswordField lozinkaTxtOpet;

    public void povratak(ActionEvent event) {
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("Main.fxml"));
            root.getStylesheets().add(Main.class.getResource("application.css").toString());
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void imeTxtVerify() {
        imeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*$")) {
                imeTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]*$", ""));
            }
        });
    }

    public void prezimeTxtVerify() {
        prezimeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*$")) {
                prezimeTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]*$", ""));
            }
        });
    }
    public void korisnickoImeTxtVerify(){
        korisnickoImeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z\\d")) {
                korisnickoImeTxt.setText(newValue.replaceAll("[^\\sa-zA-Z^\\d]", ""));
            }
        });
    }
    public void oibTxtVerify(){
        oibTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                oibTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    public void kontaktTxtVerify(){
        kontaktTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                kontaktTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    public void registracija() {

          if(imeTxt.getText().isEmpty()){
         Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
         Neuspjeh.setContentText("Ime ne smije biti prazno!");
         Neuspjeh.setHeaderText("Greška!");
         Neuspjeh.setTitle("Upozorenje");
         Neuspjeh.show();
         }
          if(prezimeTxt.getText().isEmpty()){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Prezime ne smije biti prazno!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
          if(oibTxt.getText().isEmpty()) {
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("OIB ne smije biti prazan!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
          if(kontaktTxt.getText().isEmpty()){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Kontakt ne smije biti prazan!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
          if(emailTxt.getText().isEmpty()){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Email ne smije biti prazan!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
          if(korisnickoImeTxt.getText().isEmpty()){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Korisničko ime ne smije biti prazno!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
          if(lozinkaTxt.getText().isEmpty()){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Lozinka ne smije biti prazna!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
          if(lozinkaTxtOpet.getText().isEmpty()){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Morate potvrditi lozniku!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }

          String prvaLozinka = lozinkaTxt.getText();
          String drugaLozinka = lozinkaTxtOpet.getText();

          if(!prvaLozinka.equals(drugaLozinka)){
              Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
              Neuspjeh.setContentText("Lozinke se moraju podudarati!");
              Neuspjeh.setHeaderText("Greška!");
              Neuspjeh.setTitle("Upozorenje");
              Neuspjeh.show();
          }
        else {
              Date trenutniDatum = Date.valueOf(datumRodenja.getValue());
              String enkriptiranaLozinka = org.apache.commons.codec.digest.DigestUtils.sha256Hex(lozinkaTxt.getText());

              Korisnik.dohvatiInstancu();
              Korisnik.dohvatiInstancu().unosKorisnika(imeTxt.getText(), prezimeTxt.getText(), oibTxt.getText(), kontaktTxt.getText(), emailTxt.getText(), trenutniDatum, korisnickoImeTxt.getText(), enkriptiranaLozinka);
          }
    }

}
