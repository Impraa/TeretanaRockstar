package com.example.teretanarockstar.tertanarockstar.Entieti;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

import java.sql.Date;

public class ZahtjevDjelatnikaSprave {

    private SimpleStringProperty ime;
    private SimpleObjectProperty datumNabave;
    private SimpleStringProperty proizvodac;

    public ZahtjevDjelatnikaSprave(String ime, Date datumNabave, String proizvodac) {
        this.ime = new SimpleStringProperty(ime);
        this.datumNabave = new SimpleObjectProperty(datumNabave);
        this.proizvodac = new SimpleStringProperty(proizvodac);
    }
    public String getIme() {
        return this.ime.get();
    }

    public SimpleStringProperty imeProperty() {
        return ime;
    }

    public Date getDatumNabave() {
        return (Date) this.datumNabave.get();
    }

    public SimpleObjectProperty datumNabaveProperty() {
        return datumNabave;
    }

    public String getProizvodac() {
        return this.proizvodac.get();
    }

    public SimpleStringProperty proizvodacProperty() {
        return proizvodac;
    }

    public void setIme(String ime){this.ime.set(ime);}

    public void setDatumNabave(Date datumNabave){this.datumNabave.set(datumNabave);}

    public void setProizvodac(String proizvodac){this.proizvodac.set(proizvodac);}
}
