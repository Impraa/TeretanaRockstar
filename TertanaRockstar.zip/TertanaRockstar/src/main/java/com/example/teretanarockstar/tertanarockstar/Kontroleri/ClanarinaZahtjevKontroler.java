package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Clanarina;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ClanarinaZahtjevKontroler implements Initializable {

    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public DatePicker vrijemePolaska;

    @FXML
    public JFXComboBox<String> osobniTrener;

    @FXML
    public JFXComboBox<String> nacinPlacanja;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadice.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);
        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });

        osobniTrener.getItems().addAll("Da","Ne");
        nacinPlacanja.getItems().addAll("Gotovina","Kartica","Kriptovaluta");
    }

    public void unosZahtjeva(){
        byte osobniTrenerBroj;
        if(osobniTrener.getValue().equals("Da")){
            osobniTrenerBroj=1;
        }
        else{
            osobniTrenerBroj=0;
        }

        String nacinPlacanjaTekst;
        if(nacinPlacanja.getValue().equals("Gotovina")){
            nacinPlacanjaTekst = "Gotovina";
        }
        else if(nacinPlacanja.getValue().equals("Kartica")){
            nacinPlacanjaTekst = "Kartica";
        }
        else{
            nacinPlacanjaTekst = "Kriptovaluta";
        }
        Clanarina.dohvatiInstancu();
        Clanarina.dohvatiInstancu().zahtjevClanarineKorisnik(vrijemePolaska, osobniTrenerBroj,nacinPlacanjaTekst);
    }

    public void predaniZahjteviKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("PredaniZahtjevi.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }
}
