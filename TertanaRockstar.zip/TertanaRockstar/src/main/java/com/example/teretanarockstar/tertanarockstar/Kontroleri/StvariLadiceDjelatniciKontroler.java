package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class StvariLadiceDjelatniciKontroler {

    public void odjavaKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("DjelatniciPrijava.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void odobravanjeKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("OdobravanjeZahtjeva.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void pocetnaKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("MainDjelatnici.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void spraveKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("SpravePocetna.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void kvaroviKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("KvaroviPocetna.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void ispisKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("IspisSvihKorisnika.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
