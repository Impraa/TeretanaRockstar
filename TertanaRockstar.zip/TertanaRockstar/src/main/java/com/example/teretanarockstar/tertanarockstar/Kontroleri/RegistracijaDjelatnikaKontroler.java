package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Djelatnik;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class RegistracijaDjelatnikaKontroler implements Initializable {

    @FXML
    public JFXTextField korisnickoImeAdmina;

    @FXML
    public JFXPasswordField lozinkaAdmina;

    @FXML
    public JFXTextField imeTxt;

    @FXML
    public JFXTextField prezimeTxt;

    @FXML
    public JFXTextField adresaTxt;

    @FXML
    public JFXTextField nacinZaposljavanjaTxt;

    @FXML
    public JFXTextField korisnickoImeTxt;

    @FXML
    public JFXPasswordField lozinkaTxt;

    @FXML
    public JFXCheckBox adminUpit;

    @FXML
    public JFXTextField pozicijaTxt;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        korisnickoImeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z\\d")) {
                korisnickoImeTxt.setText(newValue.replaceAll("[^\\sa-zA-Z^\\d]", ""));
            }
        });
        korisnickoImeAdmina.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z\\d")) {
                korisnickoImeAdmina.setText(newValue.replaceAll("[^\\sa-zA-Z^\\d]", ""));
            }
        });
        imeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*$")) {
                imeTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]*$", ""));
            }
        });
        prezimeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*$")) {
                prezimeTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]*$", ""));
            }
        });
        pozicijaTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*$")) {
                pozicijaTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]*$", ""));
            }
        });
    }

    public void registracijaDjelatnikaKlik (){
        if(korisnickoImeAdmina.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Korisnicko ime admina ne smije biti prazno!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(lozinkaAdmina.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Lozinka admina ne smije biti prazna!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(imeTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Ime ne smije biti prazno!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(prezimeTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Prezime ne smije biti prazno!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(adresaTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Adresa ne smije biti prazna!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(nacinZaposljavanjaTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Način zapošljavnja ne smije biti prazan!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(korisnickoImeTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Korisničko ime ne smije biti prazno!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(lozinkaTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Lozinka ne smije biti prazna!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        if(pozicijaTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Pozicija ne smije biti prazna!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
        Djelatnik.DohvatiInstancu();
        Djelatnik.DohvatiInstancu().UnosDjelatnika(korisnickoImeAdmina,lozinkaAdmina,imeTxt,prezimeTxt,adresaTxt,nacinZaposljavanjaTxt,korisnickoImeTxt,lozinkaTxt,adminUpit,pozicijaTxt);
    }

    public void povratakKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("DjelatniciPrijava.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }
}
