package com.example.teretanarockstar.tertanarockstar.Entieti;

import com.example.teretanarockstar.tertanarockstar.Helper.BazaPovezivanje;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

public class Kvar {

    public static Kvar kvarObj = null;

    private Kvar(){}

    public static synchronized Kvar dohvatiInstancu(){
        if(kvarObj == null){
            kvarObj = new Kvar();
        }
        return kvarObj;
    }
    public void UnosKvarova(JFXTextField korIme, JFXTextField imeSprave, JFXTextField proizvodacSprave, JFXDatePicker datumNabaveSprave,JFXTextField cijenaPopravka){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        CallableStatement novaProcedura = null;
        ResultSet rezultat = null;
        ResultSet noviRezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call PronadiKorisnika(?)}");

            procedura.setString(1,korIme.getText());
            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                String ime = rezultat.getString("Ime");
                String prezime = rezultat.getString("Prezime");
                String oib = rezultat.getString("OIB");
                String kontakt = rezultat.getString("Kontakt");
                String email = rezultat.getString("E_mail");
                Date datumRodenja = rezultat.getDate("Datum_Rodenja");
                String lozinka = rezultat.getString("Lozinka");

                novaProcedura = povezanost.prepareCall("{call UnosKvarova(?,?,?,?,?,?,?,?,?,?,?,?)}");

                novaProcedura.setString(1,ime);
                novaProcedura.setString(2,prezime);
                novaProcedura.setString(3,oib);
                novaProcedura.setString(4,kontakt);
                novaProcedura.setString(5,email);
                novaProcedura.setDate(6,datumRodenja);
                novaProcedura.setString(7,korIme.getText());
                novaProcedura.setString(8,lozinka);

                novaProcedura.setString(9,imeSprave.getText());
                novaProcedura.setDate(10, Date.valueOf(datumNabaveSprave.getValue()));
                novaProcedura.setString(11,proizvodacSprave.getText());
                novaProcedura.setString(12,cijenaPopravka.getText());

                noviRezultat = novaProcedura.executeQuery();
                if(noviRezultat.next()){
                    Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                    Uspjeh.setContentText("Uspješno ste unjeli kvar!");
                    Uspjeh.setHeaderText("Uspjeh!");
                    Uspjeh.setTitle("Uspjeh");
                    Uspjeh.show();
                }
                else{
                    Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                    Neuspjeh.setContentText("Došlo je do greške, molimo pokušajte ponovno!");
                    Neuspjeh.setHeaderText("Greška!");
                    Neuspjeh.setTitle("Neuspjeh");
                    Neuspjeh.show();
                }
            }else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Korisnik ne postoji!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Neuspjeh");
                Neuspjeh.show();
            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(noviRezultat != null){
                try{
                    noviRezultat.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(novaProcedura != null){
                try{
                    novaProcedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public void ispisSvihKvarova(TableView tablica, TableColumn korIme, TableColumn imeSprave, TableColumn datumNabave, TableColumn proizSprave, TableColumn cijenaPop){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        ObservableList<ZahtjevDjelatnikKvar> lista = FXCollections.observableArrayList();
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call IspisSvihKvarova()}");

            rezultat = procedura.executeQuery();
            while (rezultat.next()){

                lista.addAll(new ZahtjevDjelatnikKvar(rezultat.getString("Korisnicko_Ime"),rezultat.getString("Ime"),
                        rezultat.getDate("Datum_nabave"),rezultat.getString("Proizvodac"),rezultat.getInt("Cijena_popravka")));
                tablica.setItems(lista);

            }

            korIme.setCellValueFactory(new PropertyValueFactory<>("korIme"));
            imeSprave.setCellValueFactory(new PropertyValueFactory<>("imeSprave"));
            datumNabave.setCellValueFactory(new PropertyValueFactory<>("datumProizvodnje"));
            proizSprave.setCellValueFactory(new PropertyValueFactory<>("prozSprave"));
            cijenaPop.setCellValueFactory(new PropertyValueFactory<>("cijenaPop"));

        }catch (Exception e){

        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }

    }

    public synchronized int izvadiIDIzKvarova(String korIme,String imeSprave,Date datumNabave, String proizSprave,int cijenaPop){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        int kvarId=0;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call IspisIDIzKvarova(?,?,?,?,?)}");

            procedura.setString(1,korIme);
            procedura.setString(2,imeSprave);
            procedura.setDate(3,datumNabave);
            procedura.setString(4,proizSprave);
            procedura.setInt(5,cijenaPop);

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                kvarId = rezultat.getInt("ID");
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
        return kvarId;
    }

    public synchronized void izmjenaKvarova(String korIme,String imeSprave,Date datumNabave, String proizSprave,int kvarID,int cijenaPop){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call Izmjena_Kvarova(?,?,?,?,?,?)}");

            procedura.setString(1,korIme);
            procedura.setString(2,imeSprave);
            procedura.setDate(3,datumNabave);
            procedura.setString(4,proizSprave);
            procedura.setInt(5,kvarID);
            procedura.setInt(6,cijenaPop);

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste izmjenili kvar!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Korisnik ili sprava ne postoje, molimo pokušajte ponovno!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Neuspjeh");
                Neuspjeh.show();
            }
        }catch (Exception e){

        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public void brisanjeKvarova(int kvarID){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try {
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call BrisanjeKvarova(?)}");

            procedura.setInt(1,kvarID);
            rezultat = procedura.executeQuery();

            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste izbrisali kvar!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }
        }catch (Exception e){

        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }
}
