package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Sprava;
import com.example.teretanarockstar.tertanarockstar.Entieti.ZahtjevDjelatnikaSprave;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class IspisSvihSpravaKontroler implements Initializable {
    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public TableView<ZahtjevDjelatnikaSprave> tablica;

    @FXML
    public TableColumn<ZahtjevDjelatnikaSprave,String> ime;

    @FXML
    public TableColumn<ZahtjevDjelatnikaSprave, Date> datumNabave;

    @FXML
    public TableColumn<ZahtjevDjelatnikaSprave, String> proizvodac;

    @FXML
    public TableColumn<ZahtjevDjelatnikaSprave,Void> promjena;

    @FXML
    public TableColumn<ZahtjevDjelatnikaSprave,Void> obrisi;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadiceDjelatnici.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);

        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });
        Sprava.dohvatiInstancu();
        Sprava.dohvatiInstancu().ispisSvihSprava(tablica,ime,datumNabave,proizvodac);
        dodajPromjenaGumb();
        dodajObrisiGumb();
    }
    private void dodajPromjenaGumb() {

        Callback<TableColumn<ZahtjevDjelatnikaSprave, Void>, TableCell<ZahtjevDjelatnikaSprave, Void>> cellFactory = new Callback<TableColumn<ZahtjevDjelatnikaSprave, Void>, TableCell<ZahtjevDjelatnikaSprave, Void>>() {
            @Override
            public TableCell<ZahtjevDjelatnikaSprave, Void> call(final TableColumn<ZahtjevDjelatnikaSprave, Void> param) {
                final TableCell<ZahtjevDjelatnikaSprave, Void> cell = new TableCell<ZahtjevDjelatnikaSprave, Void>() {

                    private final JFXButton gumb = new JFXButton("Promjeni");

                    {
                        gumb.setOnAction((ActionEvent event) -> {
                            ZahtjevDjelatnikaSprave zahtjev = getTableView().getItems().get(getIndex());
                            Sprava.dohvatiInstancu();
                            int idSprava = Sprava.dohvatiInstancu().dohvatiIDSprave(zahtjev.getIme(),zahtjev.getDatumNabave(),zahtjev.getProizvodac());
                            LocalDate trenutniDatum = zahtjev.getDatumNabave().toLocalDate();
                            PromjenaSpraveKontroler promjenaSpraveKontroler = new PromjenaSpraveKontroler();
                            promjenaSpraveKontroler.setIdSprave(idSprava);
                            promjenaSpraveKontroler.postaviVrijednosti(zahtjev.getIme(),trenutniDatum,zahtjev.getProizvodac());
                            try {
                                AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("PromjenaSprave.fxml"));
                                Scene scena = new Scene(root);
                                Stage prozor = new Stage();
                                prozor.setResizable(false);

                                prozor.setScene(scena);
                                prozor.show();
                            } catch (Exception c) {
                                c.printStackTrace();
                            }
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(gumb);
                        }
                    }
                };
                return cell;
            }
        };

        promjena.setCellFactory(cellFactory);

        tablica.getColumns().add(promjena);

    }

    private void dodajObrisiGumb() {

        Callback<TableColumn<ZahtjevDjelatnikaSprave, Void>, TableCell<ZahtjevDjelatnikaSprave, Void>> cellFactory = new Callback<TableColumn<ZahtjevDjelatnikaSprave, Void>, TableCell<ZahtjevDjelatnikaSprave, Void>>() {
            @Override
            public TableCell<ZahtjevDjelatnikaSprave, Void> call(final TableColumn<ZahtjevDjelatnikaSprave, Void> param) {
                final TableCell<ZahtjevDjelatnikaSprave, Void> cell = new TableCell<ZahtjevDjelatnikaSprave, Void>() {

                    private final JFXButton gumb = new JFXButton("Obriši");

                    {
                        gumb.setOnAction((ActionEvent event) -> {
                            ZahtjevDjelatnikaSprave zahtjev = getTableView().getItems().get(getIndex());
                            Sprava.dohvatiInstancu();
                            int idSprava = Sprava.dohvatiInstancu().dohvatiIDSprave(zahtjev.getIme(),zahtjev.getDatumNabave(),zahtjev.getProizvodac());
                            Sprava.dohvatiInstancu().brisanjeSprava(idSprava);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(gumb);
                        }
                    }
                };
                return cell;
            }
        };

        obrisi.setCellFactory(cellFactory);

        tablica.getColumns().add(obrisi);

    }
}
