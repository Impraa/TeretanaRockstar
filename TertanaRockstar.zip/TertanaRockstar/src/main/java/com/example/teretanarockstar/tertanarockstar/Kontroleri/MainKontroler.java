package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Korisnik;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class MainKontroler implements Initializable {
    @FXML
    public JFXTextField korisnickoIme;

    @FXML
    public JFXTextField lozinka;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        korisnickoIme.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z\\d")) {
                korisnickoIme.setText(newValue.replaceAll("[^\\sa-zA-Z^\\d]", ""));
            }
        });
    }

    public void registrirajSe(ActionEvent event){
        try{
            BorderPane root = (BorderPane)FXMLLoader.load(Main.class.getResource("RegistracijaKorisnika.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage)((Node)event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        }
        catch(Exception c){
            c.printStackTrace();
        }
    }

    public void prijaviSe(ActionEvent event){
        try{
            Korisnik.dohvatiInstancu();
            String enkriptiranaLozinka = org.apache.commons.codec.digest.DigestUtils.sha256Hex(lozinka.getText());
            boolean odgovor = Korisnik.dohvatiInstancu().provjeriKorisnika(korisnickoIme.getText(), enkriptiranaLozinka);
            if(odgovor){
                Korisnik.dohvatiInstancu().setLoz(lozinka.getText());
                AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("Pocetna.fxml"));
                Scene scena = new Scene(root);
                Stage prozor = (Stage)((Node)event.getSource()).getScene().getWindow();

                prozor.setScene(scena);
                prozor.show();
            }
        }
        catch (Exception c){
            c.printStackTrace();
        }
    }

    public void ulogirajSeKaoDjelatnikKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("DjelatniciPrijava.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

}