package com.example.teretanarockstar.tertanarockstar.Entieti;

import com.example.teretanarockstar.tertanarockstar.Helper.BazaPovezivanje;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.time.LocalDate;

public class Korisnik {
    public static Korisnik korObj = null;

    private String ime;

    private String prezime;

    private String oib;

    private String kontakt;

    private String email;

    private Date datumRodenja;

    private String korIme;

    private String loz;

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getOib() {
        return oib;
    }

    public void setOib(String oib) {
        this.oib = oib;
    }

    public String getKontakt() {
        return kontakt;
    }

    public void setKontakt(String kontakt) {
        this.kontakt = kontakt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDatumRodenja() {
        return datumRodenja;
    }

    public void setDatumRodenja(Date datumRodenja) {
        this.datumRodenja = datumRodenja;
    }

    public String getLoz() {
        return loz;
    }

    public void setLoz(String loz) {
        this.loz = loz;
    }

    @Override
    public String toString() {
        return "Korisnik{" +
                "ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", oib='" + oib + '\'' +
                ", kontakt='" + kontakt + '\'' +
                ", email='" + email + '\'' +
                ", datumRodenja=" + datumRodenja +
                ", korIme='" + korIme + '\'' +
                ", loz='" + loz + '\'' +
                '}';
    }

    private Korisnik(){
    }

    public static synchronized Korisnik dohvatiInstancu(){
        if(korObj == null){
            korObj = new Korisnik();
        }
        return korObj;
    }
    public String getKorIme() {
        return korIme;
    }

    public void setKorIme(String korIme) {
        this.korIme = korIme;
    }

    public synchronized void unosKorisnika(String ime, String prezime, String oib, String kontakt, String email, Date datumRodenja, String korisnickoIme, String lozinka){

        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;

    try{
        povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
        procedura = povezanost.prepareCall("{call UnosKorisnika(?,?,?,?,?,?,?,?)}");

        procedura.setString(1,ime);
        procedura.setString(2,prezime);
        procedura.setString(3,oib);
        procedura.setString(4,kontakt);
        procedura.setString(5,email);
        procedura.setDate(6,datumRodenja);
        procedura.setString(7,korisnickoIme);
        procedura.setString(8,lozinka);

        rezultat = procedura.executeQuery();

        if(rezultat.next()){
            Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
            Uspjeh.setContentText("Uspješno ste se registrirali!");
            Uspjeh.setHeaderText("Čestitamo!");
            Uspjeh.setTitle("Uspjeh");
            Uspjeh.show();
        }
        else{
            Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
            Neuspjeh.setContentText("Niste ste se registrirali! Molimo promjenite Korisničko ime ili OIB!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();
        }
    }
    catch (Exception e){
        e.printStackTrace();
    }
    finally {
        if(rezultat!=null){
            try{
                rezultat.close();
            }
            catch (Exception e){
            }
        }
        if(procedura!=null){
            try{
                procedura.close();
            }
            catch (Exception e){
            }
        }
        if(povezanost!=null){
            try{
                povezanost.close();
            }
            catch (Exception e){
            }
        }
    }
    }

    public synchronized boolean provjeriKorisnika(String korisnickoIme, String lozinka){

        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        boolean provjera = false;

        try{
        povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
        procedura = povezanost.prepareCall("{call ProvjeraKorisnika(?,?)}");

        procedura.setString(1,korisnickoIme);
        procedura.setString(2,lozinka);

        rezultat = procedura.executeQuery();
        
        if(rezultat.next()){
            provjera = true;
            setIme(rezultat.getString("Ime"));
            setPrezime(rezultat.getString("Prezime"));
            setOib(rezultat.getString("OIB"));
            setKontakt(rezultat.getString("Kontakt"));
            setEmail(rezultat.getString("E_mail"));
            setDatumRodenja(rezultat.getDate("Datum_Rodenja"));
            setKorIme(korisnickoIme);
        }
        else{
            Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
            Neuspjeh.setContentText("Korisničko ime ili lozinka je pogrešna, molimo pokušajte ponovno!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Neuspjeh");
            Neuspjeh.show();
        }
        }catch (Exception e){
        }finally{
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }
                catch (Exception e){
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
        return provjera;
    }

    public synchronized void  pronadiKorisnika(JFXTextField imeTxt, JFXTextField prezimeTxt, JFXTextField oibTxt, JFXTextField kontaktTxt, JFXTextField emailTxt, DatePicker datumRodenja, JFXTextField korisnickoImeTxt){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call PronadiKorisnika(?)}");

            procedura.setString(1, getKorIme());

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                imeTxt.setText(rezultat.getString("Ime"));
                prezimeTxt.setText(rezultat.getString("Prezime"));
                oibTxt.setText(rezultat.getString("OIB"));
                kontaktTxt.setText(rezultat.getString("Kontakt"));
                emailTxt.setText(rezultat.getString("E_mail"));
                Date trenutniDatum = rezultat.getDate("Datum_Rodenja");
                datumRodenja.setValue(trenutniDatum.toLocalDate());
                korisnickoImeTxt.setText(rezultat.getString("Korisnicko_Ime"));
            }
        }catch (Exception e){
        e.printStackTrace();
    }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }
                catch (Exception e){
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
        }

        public synchronized void promjena(String korisnickoIme,String ime,String prezime,String kontkat,String email,String loznika){
            BazaPovezivanje.dohvatiInstancu();
            Connection povezanost= null;
            CallableStatement procedura = null;
            ResultSet rezultat = null;
            try{
                povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
                procedura = povezanost.prepareCall("{call IzmjenaKorisnika(?,?,?,?,?,?)}");

                String enkriptiranaLozinka = org.apache.commons.codec.digest.DigestUtils.sha256Hex(loznika);
                procedura.setString(1,korisnickoIme );
                procedura.setString(2,ime);
                procedura.setString(3,prezime);
                procedura.setString(4,kontkat);
                procedura.setString(5,email);
                procedura.setString(6,enkriptiranaLozinka);

                rezultat = procedura.executeQuery();

                if(rezultat.next()){
                    Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                    Uspjeh.setHeaderText("Promjene su spremljene.");
                    Uspjeh.setTitle("Uspjeh");
                    Uspjeh.show();
                }
                else{
                    Alert Neuspjeh = new Alert(Alert.AlertType.INFORMATION);
                    Neuspjeh.setHeaderText("Dogodila se greška, molimo pokušajte ponovno!");
                    Neuspjeh.setTitle("Neuspjeh");
                    Neuspjeh.show();
                }
            }catch (Exception e){
                e.printStackTrace();
            }finally {
                if(rezultat!=null){
                    try{
                        rezultat.close();
                    }
                    catch (Exception e){
                    }
                }
                if(procedura!=null){
                    try{
                        procedura.close();
                    }
                    catch (Exception e){
                    }
                }
                if(povezanost!=null){
                    try{
                        povezanost.close();
                    }
                    catch (Exception e){
                    }
                }
            }
        }

        public void ispisSvihKorisnika(TableView tablica, TableColumn ime,TableColumn prezime,TableColumn kontakt,TableColumn email,TableColumn korIme){
            BazaPovezivanje.dohvatiInstancu();
            Connection povezanost= null;
            CallableStatement procedura = null;
            ResultSet rezultat = null;
            ObservableList<ZahtjevDjelatnikKorisnik>lista = FXCollections.observableArrayList();
            try{
                povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
                procedura = povezanost.prepareCall("{call IspisSvihKorisnika()}");

                rezultat = procedura.executeQuery();
                while(rezultat.next()){
                    lista.addAll(new ZahtjevDjelatnikKorisnik(rezultat.getString("Ime"),rezultat.getString("Prezime"),
                            rezultat.getString("Kontakt"),rezultat.getString("E_mail"),rezultat.getString("Korisnicko_ime")));
                    tablica.setItems(lista);
                }
                ime.setCellValueFactory(new PropertyValueFactory<>("ime"));
                prezime.setCellValueFactory(new PropertyValueFactory<>("prezime"));
                kontakt.setCellValueFactory(new PropertyValueFactory<>("kontakt"));
                email.setCellValueFactory(new PropertyValueFactory<>("email"));
                korIme.setCellValueFactory(new PropertyValueFactory<>("korisnickoIme"));
            }catch (Exception e){
                e.printStackTrace();
            }finally {
                if(rezultat!=null){
                    try{
                        rezultat.close();
                    }
                    catch (Exception e){
                    }
                }
                if(procedura!=null){
                    try{
                        procedura.close();
                    }
                    catch (Exception e){
                    }
                }
                if(povezanost!=null){
                    try{
                        povezanost.close();
                    }
                    catch (Exception e){
                    }
            }
        }
    }

}
