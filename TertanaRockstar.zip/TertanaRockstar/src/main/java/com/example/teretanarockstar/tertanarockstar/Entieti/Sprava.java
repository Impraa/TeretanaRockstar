package com.example.teretanarockstar.tertanarockstar.Entieti;

import com.example.teretanarockstar.tertanarockstar.Helper.BazaPovezivanje;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

public class Sprava {
    public static Sprava spravaObj = null;

    private Sprava(){}

    public static synchronized Sprava dohvatiInstancu(){
        if(spravaObj==null){
            spravaObj = new Sprava();
        }
        return spravaObj;
    }

    public void unosSprava(JFXTextField ime, JFXDatePicker datumNabave,JFXTextField proizvodaca){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call UnosSprave(?,?,?)}");

            procedura.setString(1,ime.getText());
            procedura.setString(3,proizvodaca.getText());
            Date trenutniDatum = Date.valueOf(datumNabave.getValue());
            procedura.setDate(2,trenutniDatum);

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste unjeli spravu!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Došlo je do greške, molimo pokušajte ponovno!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Neuspjeh");
                Neuspjeh.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }
                catch (Exception e){
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public void ispisSvihSprava(TableView tablica, TableColumn ime, TableColumn datumNabave,TableColumn proizvodac){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        ObservableList<ZahtjevDjelatnikaSprave> lista = FXCollections.observableArrayList();
        try {
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("call IspisSvihSprava('')");

            rezultat = procedura.executeQuery();
            while (rezultat.next()){
                lista.add(new ZahtjevDjelatnikaSprave(rezultat.getString("Ime"),rezultat.getDate("Datum_nabave"),
                        rezultat.getString("Proizvodac")));
                tablica.setItems(lista);
            }

            ime.setCellValueFactory(new PropertyValueFactory<>("ime"));
            datumNabave.setCellValueFactory(new PropertyValueFactory<>("datumNabave"));
            proizvodac.setCellValueFactory(new PropertyValueFactory<>("proizvodac"));

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public int dohvatiIDSprave(String ime,Date datumNabave,String proizvodac){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        int spravaID = 0;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call IspisIDIzSprava(?,?,?)}");

            procedura.setString(1, ime);
            procedura.setDate(2,datumNabave);
            procedura.setString(3,proizvodac);

            rezultat  = procedura.executeQuery();
            if(rezultat.next()){
                spravaID = rezultat.getInt("ID");
            }
        }catch (Exception e){

        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
        return spravaID;
    }

    public void izmjeniSpravu(int spravaID,JFXTextField ime,JFXDatePicker datumNabave,JFXTextField proizvodac){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call izmjena_sprave(?,?,?,?)}");

            procedura.setInt(1,spravaID);
            procedura.setString(2,ime.getText());
            Date datum = Date.valueOf(datumNabave.getValue());
            procedura.setDate(3,datum);
            procedura.setString(4,proizvodac.getText());

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste izmjenili spravu!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public void brisanjeSprava(int idSprave){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call BrisanjeSprave(?)}");

            procedura.setInt(1,idSprave);
            rezultat = procedura.executeQuery();

            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste izbrisali spravu!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }
}
