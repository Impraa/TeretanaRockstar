package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Clanarina;
import com.example.teretanarockstar.tertanarockstar.Entieti.ZahtjevKorisnikaClanarine;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;

public class PredaniZahtjeviKontroler implements Initializable {
    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public TableView<ZahtjevKorisnikaClanarine> tablica;

    @FXML
    public TableColumn<ZahtjevKorisnikaClanarine, Date> vrijemePolaska;

    @FXML
    public TableColumn<ZahtjevKorisnikaClanarine, Integer> osobniTrener;

    @FXML
    public TableColumn<ZahtjevKorisnikaClanarine,String> presudaZahtjeva;

    @FXML
    public TableColumn<ZahtjevKorisnikaClanarine,String> vrstaPlacanja;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadice.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);
        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });

        Clanarina.dohvatiInstancu().pregledZahtjeva(tablica,vrijemePolaska,osobniTrener,presudaZahtjeva,vrstaPlacanja);
    }
}
