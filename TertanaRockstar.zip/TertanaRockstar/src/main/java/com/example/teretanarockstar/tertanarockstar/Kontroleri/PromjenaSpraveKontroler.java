package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Sprava;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class PromjenaSpraveKontroler implements Initializable {
    @FXML
    public JFXTextField ime;

    @FXML
    public JFXDatePicker datumNabave;

    @FXML
    public JFXTextField proizvodac;

    static int idSprave;
    static String imeTxt;
    static LocalDate datumNabaveVar;
    static String proizvodacTxt;

    public void setIdSprave(int idSprava){
        this.idSprave = idSprava;
    }

    public void postaviVrijednosti(String ime,LocalDate datumNabave,String proizvodac){
        imeTxt = ime;
        datumNabaveVar = datumNabave;
        proizvodacTxt = proizvodac;
    }

    public void izmjenaKlik(){
        Sprava.dohvatiInstancu();
        Sprava.dohvatiInstancu().izmjeniSpravu(idSprave,ime,datumNabave,proizvodac);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ime.setText(imeTxt);
        datumNabave.setValue(datumNabaveVar);
        proizvodac.setText(proizvodacTxt);
    }
}
