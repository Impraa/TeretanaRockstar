package com.example.teretanarockstar.tertanarockstar.Entieti;

import com.example.teretanarockstar.tertanarockstar.Helper.BazaPovezivanje;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.time.LocalDate;

public class Clanarina {
    public static Clanarina clanObj = null;

    public static synchronized Clanarina dohvatiInstancu(){
        if(clanObj == null){
            clanObj = new Clanarina();
        }
        return clanObj;
    }
    private Clanarina(){}

    public synchronized void zahtjevClanarineKorisnik(DatePicker vrijemePolaska, Byte osobniTrener, String nacinPlacnja){
        BazaPovezivanje.dohvatiInstancu();
        Korisnik.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.povObj.dohvatiVezu();
            procedura = povezanost.prepareCall("{call UnosClanarina(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

            procedura.setString(1,Korisnik.dohvatiInstancu().getIme());
            procedura.setString(2,Korisnik.dohvatiInstancu().getPrezime());
            procedura.setString(3,Korisnik.dohvatiInstancu().getOib());
            procedura.setString(4,Korisnik.dohvatiInstancu().getKontakt());
            procedura.setString(5,Korisnik.dohvatiInstancu().getEmail());
            procedura.setDate(6,Korisnik.dohvatiInstancu().getDatumRodenja());
            procedura.setString(7,Korisnik.dohvatiInstancu().getKorIme());
            String enkriptiranaLozinka = org.apache.commons.codec.digest.DigestUtils.sha256Hex(Korisnik.dohvatiInstancu().getLoz());
            procedura.setString(8,enkriptiranaLozinka);

            Date trenutniDatum = Date.valueOf(vrijemePolaska.getValue());
            procedura.setDate(9, trenutniDatum);
            LocalDate istekDatum = LocalDate.of(1999, 1, 1);
            procedura.setDate(10, Date.valueOf(istekDatum));
            procedura.setByte(11,osobniTrener);
            procedura.setInt(12, 0);
            LocalDate datumPlacanja = LocalDate.of(1999, 1, 1);
            procedura.setDate(13, Date.valueOf(datumPlacanja));
            procedura.setString(14, "Na čekanju");
            procedura.setString(15,nacinPlacnja);

            procedura.setString(16,"");
            procedura.setString(17,"");
            procedura.setString(18,"");
            procedura.setString(19,"");
            procedura.setString(20,"");

            rezultat = procedura.executeQuery();

            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Molimo pričkajte, da djelatnik odobri vaš zahtjev!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }
            else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Došlo je do greške, molimo pokušajte ponovno!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Neuspjeh");
                Neuspjeh.show();
            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }

    }

    public synchronized void pregledZahtjeva(TableView tablica,TableColumn vrijemePolaska, TableColumn osobniTrener, TableColumn presudaZahtjeva,TableColumn vrstaPlacanja){
       BazaPovezivanje.dohvatiInstancu();
       Korisnik.dohvatiInstancu();
       Connection povezanost = null;
       CallableStatement procedura = null;
       ResultSet rezultat = null;
        ObservableList<ZahtjevKorisnikaClanarine> lista = FXCollections.observableArrayList();
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call IspisClanarinaKorisnik(?)}");

            procedura.setString(1,Korisnik.dohvatiInstancu().getKorIme());
            rezultat = procedura.executeQuery();
            while(rezultat.next()){
                lista.add(new ZahtjevKorisnikaClanarine(rezultat.getDate("Vrijeme_polaska"),rezultat.getInt("Osobni_trener"),
                        rezultat.getString("Presuda_Zahtjeva"), rezultat.getString("Opis")));
                tablica.setItems(lista);
            }
            vrijemePolaska.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine, java.util.Date>("vrijemePolaska"));
            osobniTrener.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine,Integer>("osobniTrener"));
            presudaZahtjeva.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine,String>("presudaZahtjeva"));
            vrstaPlacanja.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine,String>("vrstaPlacanja"));

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public synchronized void pregledKorisnikovihZahtjeva(TableView tablica,TableColumn korisnickoIme,TableColumn vrijemePolaska,TableColumn istekClanarine,TableColumn cijenaClanarine){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        ObservableList<ZahjtevDjelatnikaClanarine> lista = FXCollections.observableArrayList();
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call IspisSvihClanarina()}");
            rezultat = procedura.executeQuery();
            while(rezultat.next()){
                lista.add(new ZahjtevDjelatnikaClanarine(rezultat.getString("Korisnicko_ime"),rezultat.getDate("Vrijeme_polaska"),
                        rezultat.getDate("Istek_clanarine"), rezultat.getInt("Cijena_clanarine")));
                tablica.setItems(lista);
            }
            korisnickoIme.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine,String>("korisnickoIme"));
            vrijemePolaska.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine, java.util.Date>("vrijemePolaska"));
            istekClanarine.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine, java.util.Date>("istekClanarine"));
            cijenaClanarine.setCellValueFactory(new PropertyValueFactory<ZahtjevKorisnikaClanarine,Integer>("cijenaClanarine"));

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public void izmjenaClanarinaDjelatnik(String korime,JFXDatePicker vrijemePolaska, JFXDatePicker istekClanarine, JFXTextField cijenaClanarine, JFXDatePicker datumPlacanja){

        BazaPovezivanje.dohvatiInstancu();
        Djelatnik.DohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try {
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call Izmjena_Clanarina(?,?,?,?,?,?,?)}");

            procedura.setString(1,korime);
            procedura.setString(2,Djelatnik.DohvatiInstancu().getKorisnickoIme());
            String enkriptiranaLozinka = org.apache.commons.codec.digest.DigestUtils.sha256Hex(Djelatnik.DohvatiInstancu().getLozinka());
            procedura.setString(3,enkriptiranaLozinka);
            Date trenutniDatum = Date.valueOf(vrijemePolaska.getValue());
            procedura.setDate(4,trenutniDatum);

            Date trenutniDatum2 = Date.valueOf(istekClanarine.getValue());
            procedura.setDate(5,trenutniDatum2);
            procedura.setInt(6,Integer.parseInt(cijenaClanarine.getText()));
            Date trenutniDatum3 = Date.valueOf(datumPlacanja.getValue());
            procedura.setDate(7,trenutniDatum3);

            rezultat = procedura.executeQuery();

            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste korisniku odobrili zahtjev!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }
            else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Došlo je do greške, molimo pokušajte ponovno!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Neuspjeh");
                Neuspjeh.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public synchronized int IspisVrstePlacanjaIDIzClanarine(String korIme,Date vriPolaska){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        int VrstaPlacanjaID= 0;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call IspisVPIzClanarine(?,?)}");

            procedura.setString(1,korIme);
            procedura.setDate(2,vriPolaska);

            rezultat = procedura.executeQuery();

            if(rezultat.next()){
                VrstaPlacanjaID = rezultat.getInt("Vrsta_Placanja_ID");
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
        return VrstaPlacanjaID;
    }

    public synchronized void BrisanjeClanarine(String korIme,Date vriPolaska, int vrstaPlacanjaID){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call BrisanjeClanirna(?,?,?)}");

            procedura.setString(1,korIme);
            procedura.setDate(2,vriPolaska);
            procedura.setInt(3,vrstaPlacanjaID);

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste izbrisali korisnikov zahtjev!");
                Uspjeh.setHeaderText("Uspjeh!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Došlo je do greške, molimo pokušajte ponovno!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Neuspjeh");
                Neuspjeh.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

}
