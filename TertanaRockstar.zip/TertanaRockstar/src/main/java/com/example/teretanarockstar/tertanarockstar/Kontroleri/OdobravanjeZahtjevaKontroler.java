package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Clanarina;
import com.example.teretanarockstar.tertanarockstar.Entieti.ZahjtevDjelatnikaClanarine;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.sql.Date;
import java.util.ResourceBundle;

public class OdobravanjeZahtjevaKontroler implements Initializable {
    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public TableView<ZahjtevDjelatnikaClanarine> tablica;

    @FXML
    public TableColumn<ZahjtevDjelatnikaClanarine,String> korisnickoIme;

    @FXML
    public TableColumn<ZahjtevDjelatnikaClanarine, Date>  vrijemePolaska;

    @FXML
    public TableColumn<ZahjtevDjelatnikaClanarine, Date>  istekClanarine;

    @FXML
    public TableColumn<ZahjtevDjelatnikaClanarine, Integer> cijenaClanarine;

    @FXML
    public TableColumn<ZahjtevDjelatnikaClanarine,Void> promjena;

    @FXML
    public TableColumn<ZahjtevDjelatnikaClanarine,Void> obrisi;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadiceDjelatnici.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);

        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });
        Clanarina.dohvatiInstancu();
        Clanarina.dohvatiInstancu().pregledKorisnikovihZahtjeva(tablica,korisnickoIme,vrijemePolaska,istekClanarine,cijenaClanarine);
        promjena.setCellValueFactory(new PropertyValueFactory<>("Promjena"));
        dodajPromjenaGumb();
        dodajIzbrisiGumb();
    }

    private void dodajPromjenaGumb() {

        Callback<TableColumn<ZahjtevDjelatnikaClanarine, Void>, TableCell<ZahjtevDjelatnikaClanarine, Void>> cellFactory = new Callback<TableColumn<ZahjtevDjelatnikaClanarine, Void>, TableCell<ZahjtevDjelatnikaClanarine, Void>>() {
            @Override
            public TableCell<ZahjtevDjelatnikaClanarine, Void> call(final TableColumn<ZahjtevDjelatnikaClanarine, Void> param) {
                final TableCell<ZahjtevDjelatnikaClanarine, Void> cell = new TableCell<ZahjtevDjelatnikaClanarine, Void>() {

                    private final JFXButton gumb = new JFXButton("Promjeni");

                    {
                        gumb.setOnAction((ActionEvent event) -> {
                            ZahjtevDjelatnikaClanarine zahtjev = getTableView().getItems().get(getIndex());
                            Date datum = (Date) zahtjev.getVrijemePolaska();
                            LocalDate trenutnidatum = datum.toLocalDate();
                            Date datumistek = (Date) zahtjev.getIstekClanarine();
                            LocalDate trenutniDatumIstek = datumistek.toLocalDate();
                            PromjenaZahtjevaClanarineKontroler promjenaZahtjevaClanarineKontroler = new PromjenaZahtjevaClanarineKontroler();
                            promjenaZahtjevaClanarineKontroler.postaviVrijednost(zahtjev.getKorisnickoIme(),trenutnidatum,trenutniDatumIstek,zahtjev.getCijenaClanarine());
                            try {
                                AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("PromjenaZahtjevaClanarine.fxml"));
                                Scene scena = new Scene(root);
                                Stage prozor = new Stage();
                                prozor.setResizable(false);

                                prozor.setScene(scena);
                                prozor.show();
                            } catch (Exception c) {
                                c.printStackTrace();
                            }
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(gumb);
                        }
                    }
                };
                return cell;
            }
        };

        promjena.setCellFactory(cellFactory);

        tablica.getColumns().add(promjena);

    }

    private void dodajIzbrisiGumb(){
        Callback<TableColumn<ZahjtevDjelatnikaClanarine, Void>, TableCell<ZahjtevDjelatnikaClanarine, Void>> cellFactory = new Callback<TableColumn<ZahjtevDjelatnikaClanarine, Void>, TableCell<ZahjtevDjelatnikaClanarine, Void>>() {
            @Override
            public TableCell<ZahjtevDjelatnikaClanarine, Void> call(final TableColumn<ZahjtevDjelatnikaClanarine, Void> param) {
                final TableCell<ZahjtevDjelatnikaClanarine, Void> cell = new TableCell<ZahjtevDjelatnikaClanarine, Void>() {

                    private final JFXButton gumb = new JFXButton("Obriši");

                    {
                        gumb.setOnAction((ActionEvent event) -> {
                            ZahjtevDjelatnikaClanarine zahtjev = getTableView().getItems().get(getIndex());
                            Clanarina.dohvatiInstancu();
                            int VrstaPlacanjaID = Clanarina.dohvatiInstancu().IspisVrstePlacanjaIDIzClanarine(zahtjev.getKorisnickoIme(), (java.sql.Date) zahtjev.getVrijemePolaska());
                            Clanarina.dohvatiInstancu().BrisanjeClanarine(zahtjev.getKorisnickoIme(),(java.sql.Date) zahtjev.getVrijemePolaska(),VrstaPlacanjaID);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(gumb);
                        }
                    }
                };
                return cell;
            }
        };

        obrisi.setCellFactory(cellFactory);

        tablica.getColumns().add(obrisi);
    }

}
