package com.example.teretanarockstar.tertanarockstar.Entieti;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

public class ZahtjevDjelatnikKorisnik {

    private SimpleStringProperty ime,prezime,email,korisnickoIme,kontakt;

    public ZahtjevDjelatnikKorisnik(String ime, String prezime,String kontakt, String  email, String korisnickoIme) {
        this.ime = new SimpleStringProperty(ime);
        this.prezime = new SimpleStringProperty(prezime);
        this.email = new SimpleStringProperty(email);
        this.korisnickoIme = new SimpleStringProperty(korisnickoIme);
        this.kontakt = new SimpleStringProperty(kontakt);
    }

    public String getIme() {return ime.get();}

    public SimpleStringProperty imeProperty() {return ime;}

    public String getPrezime() {return prezime.get();}

    public SimpleStringProperty prezimeProperty() {return prezime;}

    public String getEmail() {return email.get();}

    public SimpleStringProperty emailProperty() {return email;}

    public String getKorisnickoIme() {return korisnickoIme.get();}

    public SimpleStringProperty korisnickoImeProperty() {return korisnickoIme;}

    public String getKontakt() {return kontakt.get();}

    public SimpleStringProperty kontaktProperty() {return kontakt;}

    public void setIme(String ime){
        this.ime.set(ime);
    }

    public void setPrezime(String prezime){
        this.prezime.set(prezime);
    }

    public void setEmail(String email){
        this.email.set(email);
    }

    public void setKorisnickoIme(String korisnickoIme){
        this.korisnickoIme.set(korisnickoIme);
    }

    public void setKontakt(String kontakt){
        this.kontakt.set(kontakt);
    }
}
