package com.example.teretanarockstar.tertanarockstar.Entieti;

import com.example.teretanarockstar.tertanarockstar.Helper.BazaPovezivanje;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.scene.control.Alert;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

public class Djelatnik {
    public static Djelatnik djelObj = null;
    public static synchronized Djelatnik DohvatiInstancu(){
        if(djelObj == null) {
            djelObj = new Djelatnik();
        }
            return djelObj;
    }
    private Djelatnik(){
    }

    @Override
    public String toString() {
        return "Djelatnik{" +
                "korisnickoIme='" + korisnickoIme + '\'' +
                ", lozinka='" + lozinka + '\'' +
                '}';
    }

    private String korisnickoIme;
    private String lozinka;

    public String getKorisnickoIme() {
        return korisnickoIme;
    }

    public void setKorisnickoIme(String korisnickoIme) {
        this.korisnickoIme = korisnickoIme;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public void UnosDjelatnika(JFXTextField korImeAdmina, JFXPasswordField lozAdmina, JFXTextField imeTxt, JFXTextField prezimeTxt, JFXTextField adresaTxt, JFXTextField nacinZaposljavanjaTxt, JFXTextField korisnickoImeTxt, JFXPasswordField lozinkaTxt, JFXCheckBox adminUpit, JFXTextField pozicijaTxt){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call UnosDjelatnika(?,?,?,?,?,?,?,?,?,?)}");

            procedura.setString(1,korImeAdmina.getText());
            String enkriptiranaLozinkaAdmina = org.apache.commons.codec.digest.DigestUtils.sha256Hex(lozAdmina.getText());
            procedura.setString(2,enkriptiranaLozinkaAdmina);
            procedura.setString(3,imeTxt.getText());
            procedura.setString(4,prezimeTxt.getText());
            procedura.setString(5,adresaTxt.getText());
            procedura.setString(6,nacinZaposljavanjaTxt.getText());
            procedura.setString(7,pozicijaTxt.getText());
            boolean adminUpitVar = false;
            if(adminUpit.isSelected()){
                adminUpitVar = true;
            }

            procedura.setBoolean(8,adminUpitVar);
            procedura.setString(9,korisnickoImeTxt.getText());
            String enkriptiranaLozinka = org.apache.commons.codec.digest.DigestUtils.sha256Hex(lozinkaTxt.getText());
            procedura.setString(10,enkriptiranaLozinka);

            rezultat = procedura.executeQuery();

            if(rezultat.next()){
                Alert Uspjeh = new Alert(Alert.AlertType.INFORMATION);
                Uspjeh.setContentText("Uspješno ste registrirali djelatnika!");
                Uspjeh.setHeaderText("Čestitamo!");
                Uspjeh.setTitle("Uspjeh");
                Uspjeh.show();
            }
            else{
                Alert Neuspjeh = new Alert(Alert.AlertType.WARNING);
                Neuspjeh.setContentText("Niste ste registrirali djelatnika! Molimo promjenite Korisničko ime!");
                Neuspjeh.setHeaderText("Greška!");
                Neuspjeh.setTitle("Upozorenje");
                Neuspjeh.show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
    }

    public boolean provjeraDjelatnika(JFXTextField korime,JFXPasswordField loz){
        BazaPovezivanje.dohvatiInstancu();
        Connection povezanost = null;
        CallableStatement procedura = null;
        ResultSet rezultat = null;
        boolean odgovor = false;
        try{
            povezanost = BazaPovezivanje.dohvatiInstancu().dohvatiVezu();
            procedura = povezanost.prepareCall("{call ProvjeraDjelatnika(?,?)}");

            procedura.setString(1,korime.getText());
            String enkriptiranaLozinka =org.apache.commons.codec.digest.DigestUtils.sha256Hex(loz.getText());
            procedura.setString(2,enkriptiranaLozinka);

            rezultat = procedura.executeQuery();
            if(rezultat.next()){
                setKorisnickoIme(korime.getText());
                String sifra = loz.getText();
                setLozinka(sifra);
                odgovor = true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(rezultat!=null){
                try{
                    rezultat.close();
                }
                catch (Exception e){
                }
            }
            if(procedura!=null){
                try{
                    procedura.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
            if(povezanost!=null){
                try{
                    povezanost.close();
                }
                catch (Exception e){
                }
            }
        }
        return odgovor;
    }
}
