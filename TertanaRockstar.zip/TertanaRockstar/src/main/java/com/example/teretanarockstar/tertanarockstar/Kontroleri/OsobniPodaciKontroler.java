package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Korisnik;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class OsobniPodaciKontroler implements Initializable {

    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public JFXTextField imeTxt;

    @FXML
    public JFXTextField prezimeTxt;

    @FXML
    public JFXTextField oibTxt;

    @FXML
    public JFXTextField kontaktTxt;

    @FXML
    public JFXTextField emailTxt;

    @FXML
    public DatePicker datumRodenja;

    @FXML
    public JFXTextField korisnickoImeTxt;

    @FXML
    public JFXPasswordField lozinkaTxt;

    @FXML
    public JFXPasswordField opetLozinkaTxt;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadice.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);
        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });

        imeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*")) {
                imeTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]", ""));
            }
        });

        prezimeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-žA-Ž*")) {
                prezimeTxt.setText(newValue.replaceAll("[^\\sa-žA-Ž]", ""));
            }
        });

        kontaktTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                kontaktTxt.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });

        korisnickoImeTxt.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\sa-zA-Z\\d")) {
                korisnickoImeTxt.setText(newValue.replaceAll("[^\\sa-zA-Z^\\d]", ""));
            }
        });

        Korisnik.dohvatiInstancu();
        Korisnik.dohvatiInstancu().pronadiKorisnika(imeTxt, prezimeTxt, oibTxt, kontaktTxt, emailTxt, datumRodenja, korisnickoImeTxt);
        lozinkaTxt.setText(Korisnik.dohvatiInstancu().getLoz());
    }

    public void izmjenaKlik(){
        Korisnik.dohvatiInstancu();
        if(!lozinkaTxt.equals(opetLozinkaTxt) && !opetLozinkaTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.INFORMATION);
            Neuspjeh.setHeaderText("Lozinke vam se razlikuju!");
            Neuspjeh.setTitle("Neuspjeh");
            Neuspjeh.show();
        }
        if(lozinkaTxt.equals(opetLozinkaTxt)){
            Korisnik.dohvatiInstancu().promjena(korisnickoImeTxt.getText(),imeTxt.getText(),prezimeTxt.getText(),kontaktTxt.getText(),emailTxt.getText(),lozinkaTxt.getText());
        }
        if(opetLozinkaTxt.getText().isEmpty() && Objects.equals(lozinkaTxt.getText(),Korisnik.dohvatiInstancu().getLoz())){
            Korisnik.dohvatiInstancu().promjena(korisnickoImeTxt.getText(),imeTxt.getText(),prezimeTxt.getText(),kontaktTxt.getText(),emailTxt.getText(),lozinkaTxt.getText());
        }
        if(!Objects.equals(lozinkaTxt.getText(), Korisnik.dohvatiInstancu().getLoz())){
            Alert Neuspjeh = new Alert(Alert.AlertType.INFORMATION);
            Neuspjeh.setHeaderText("Lozinka se razlikuje od zadane!");
            Neuspjeh.setTitle("Neuspjeh");
            Neuspjeh.show();
        }
        if(lozinkaTxt.getText().isEmpty() && opetLozinkaTxt.getText().isEmpty()){
            Alert Neuspjeh = new Alert(Alert.AlertType.INFORMATION);
            Neuspjeh.setHeaderText("Molimo unesite lozinku!");
            Neuspjeh.setTitle("Neuspjeh");
            Neuspjeh.show();
        }
    }
}
