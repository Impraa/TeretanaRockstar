package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Djelatnik;
import com.example.teretanarockstar.tertanarockstar.Entieti.Korisnik;
import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DjelatniciPrijavaKontroler {

    @FXML
    public JFXTextField korisnickoImeTxt;

    @FXML
    public JFXPasswordField lozinkaTxt;

    public void registrirajSeKlik(ActionEvent event){
        try {
            AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("RegistracijaDjelatnika.fxml"));
            Scene scena = new Scene(root);
            Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

            prozor.setScene(scena);
            prozor.show();
        } catch (Exception c) {
            c.printStackTrace();
        }
    }

    public void prijaviSeKlik(ActionEvent event){
        Djelatnik.DohvatiInstancu();
        boolean odgovor = Djelatnik.DohvatiInstancu().provjeraDjelatnika(korisnickoImeTxt,lozinkaTxt);

        if(odgovor){
            try {
                AnchorPane root = (AnchorPane) FXMLLoader.load(Main.class.getResource("MainDjelatnici.fxml"));
                Scene scena = new Scene(root);
                Stage prozor = (Stage) ((Node) event.getSource()).getScene().getWindow();

                prozor.setScene(scena);
                prozor.show();
            } catch (Exception c) {
                c.printStackTrace();
            }
        }
        else{
            Alert Neuspjeh = new Alert(Alert.AlertType.ERROR);
            Neuspjeh.setContentText("Lozinka ili korisničko ime se ne podudaraju!");
            Neuspjeh.setHeaderText("Greška!");
            Neuspjeh.setTitle("Upozorenje");
            Neuspjeh.show();

        }
    }
}
