package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Main;
import com.jfoenix.controls.JFXDrawer;
import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.transitions.hamburger.HamburgerSlideCloseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class BMIKalkulatorKontroler implements Initializable {
    @FXML
    public JFXHamburger hamburger;

    @FXML
    public JFXDrawer ladica;

    @FXML
    public JFXTextField visina;

    @FXML
    public JFXTextField tezina;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        VBox box = null;
        try {
            box = FXMLLoader.load(Main.class.getResource("StvariLadice.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        ladica.setSidePane(box);
        HamburgerSlideCloseTransition tranzicija = new HamburgerSlideCloseTransition(hamburger);

        hamburger.addEventHandler(MouseEvent.MOUSE_PRESSED,(e)->{


            tranzicija.play();
            if(ladica.isOpened()){
                ladica.close();
            }
            else{
                ladica.open();
            }
        });
    }

    public void tezinaVerify(){
        tezina.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                tezina.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    public void visinaVerify(){
        visina.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                visina.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    public void racunanjeBMI(){
        double vis = Double.parseDouble(visina.getText()) / 100;
        double tez = Double.parseDouble(tezina.getText());

        if(tez/Math.pow(vis,2)<18.5){
            Alert Upozorenje = new Alert(Alert.AlertType.INFORMATION);
            Upozorenje.setContentText("Manje od prosjeka");
            Upozorenje.setHeaderText("Tvoj BMI Iznosi "+ tez/Math.pow(vis,2));
            Upozorenje.setTitle("Upozorenje");
            Upozorenje.show();
        }
        else if(tez/Math.pow(vis,2)>18.5 && tez/Math.pow(vis,2)<25){
            Alert Upozornje = new Alert(Alert.AlertType.INFORMATION);
            Upozornje.setContentText("Idealno");
            Upozornje.setHeaderText("Tvoj BMI Iznosi "+ tez/Math.pow(vis,2));
            Upozornje.setTitle("Upozorenje");
            Upozornje.show();
        }
        else if(tez/Math.pow(vis,2)>25){
            Alert Upozorenje = new Alert(Alert.AlertType.ERROR);
            Upozorenje.setContentText("Više od prosjeka!");
            Upozorenje.setHeaderText("Tvoj BMI Iznosi "+ tez/Math.pow(vis,2));
            Upozorenje.setTitle("Upozorenje");
            Upozorenje.show();
        }
    }
}
