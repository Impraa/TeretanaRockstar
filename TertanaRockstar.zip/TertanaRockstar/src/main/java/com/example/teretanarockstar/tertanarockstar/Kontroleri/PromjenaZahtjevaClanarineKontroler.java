package com.example.teretanarockstar.tertanarockstar.Kontroleri;

import com.example.teretanarockstar.tertanarockstar.Entieti.Clanarina;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;

public class PromjenaZahtjevaClanarineKontroler implements Initializable {

    @FXML
    public JFXDatePicker vrijemePolaska;

    @FXML
    public JFXDatePicker istekClanarine;

    @FXML
    public JFXTextField cijenaClanarine;

    @FXML
    public JFXDatePicker datumPlacnja;

    public static LocalDate vriPolaska;
    public static LocalDate istClanarine;
    public static int cijena;
    public static String korime;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cijenaClanarine.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                cijenaClanarine.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        vrijemePolaska.setValue(vriPolaska);
        istekClanarine.setValue(istClanarine);
        cijenaClanarine.setText(String.valueOf(cijena));
        datumPlacnja.setValue(LocalDate.now());
    }
    public void postaviVrijednost(String Korime,LocalDate datum,LocalDate datumistek,int cijena){
        vriPolaska = datum;
        istClanarine=datumistek;
        this.cijena = cijena;
        korime  = Korime;
    }
    public void izmjeniKlik(){
        Clanarina.dohvatiInstancu();
        Clanarina.dohvatiInstancu().izmjenaClanarinaDjelatnik(korime,vrijemePolaska,istekClanarine,cijenaClanarine,datumPlacnja);
    }
}
