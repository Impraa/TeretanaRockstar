package com.example.teretanarockstar.tertanarockstar.Entieti;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;

import java.sql.Date;

public class ZahtjevDjelatnikKvar {

    private SimpleStringProperty korIme;
    private SimpleStringProperty imeSprave;
    private SimpleObjectProperty datumProizvodnje;
    private SimpleStringProperty prozSprave;
    private SimpleIntegerProperty cijenaPop;

    public ZahtjevDjelatnikKvar(String korIme, String imeSprave, Date datumProizvodnje, String prozSprave, int cijenaPop) {
        this.korIme = new SimpleStringProperty(korIme);
        this.imeSprave = new SimpleStringProperty(imeSprave);
        this.datumProizvodnje = new SimpleObjectProperty(datumProizvodnje);
        this.prozSprave = new SimpleStringProperty(prozSprave);
        this.cijenaPop = new SimpleIntegerProperty(cijenaPop);
    }

    public String getKorIme() {return korIme.get();}

    public SimpleStringProperty korImeProperty() {return korIme;}

    public String getImeSprave() {return imeSprave.get();}

    public SimpleStringProperty imeSpraveProperty() {return imeSprave;}

    public Object getDatumProizvodnje() {return datumProizvodnje.get();}

    public SimpleObjectProperty datumProizvodnjeProperty() {return datumProizvodnje;}

    public String getProzSprave() {return prozSprave.get();}

    public SimpleStringProperty prozSpraveProperty() {return prozSprave;}

    public int getCijenaPop() {return cijenaPop.get();}

    public SimpleIntegerProperty cijenaPopProperty() {return cijenaPop;}

    public void setKorIme(String korIme){
        this.korIme.set(korIme);
    }

    public void setImeSprave(String imeSprave){
        this.imeSprave.set(imeSprave);
    }

    public void setDatumProizvodnje(Date datumProizvodnje){
        this.datumProizvodnje.set(datumProizvodnje);
    }

    public void setProzSprave(String prozSprave){
        this.prozSprave.set(prozSprave);
    }

    public void setCijenaPop(int cijenaPop){
        this.cijenaPop.set(cijenaPop);
    }
}
